# Uninstall Holster

## In-game
If you have collected the holster, take out any items inside the inventory holster slot and save the game.
> [!CAUTION]
> Any items inside the holster slot may be lost when loading a save after uninstalling the mod.

## Mod files
To uninstall the holster mod remove the following directory and all of its contents:
```
BepInEx/plugins/PistolHolster
```

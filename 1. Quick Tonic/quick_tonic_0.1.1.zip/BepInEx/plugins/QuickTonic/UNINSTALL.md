There is no in-game action you need to perform as this mod does not affect save files.
Simply delete `BepInEx/plugins/QuickTonic` and its contents.
